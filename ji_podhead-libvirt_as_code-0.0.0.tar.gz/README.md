# libvirt_as_code
automatically creates vms, installs libvirt, updates vault, signs ssh keys, creates passwords and facts, provisiones machines using cloudinit.
